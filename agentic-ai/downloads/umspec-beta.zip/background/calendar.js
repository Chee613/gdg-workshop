(function (root) {
  'use strict';
  const core = () => root.UmSpecCalendarCore || require('../shared/calendar-core.js');
  const BASE = '/calendar/v3';
  function failure(message, code, status) { return Object.assign(new Error(message), { code, status }); }
  function checkBinding(binding) {
    if (!binding || typeof binding.hash !== 'string' || !binding.hash || new TextEncoder().encode(binding.hash).length > 1024 || /[\u0000-\u001f]/.test(binding.hash) || !binding.spectrumUserId || !binding.googleSub) throw failure('A verified account binding is required', 'INVALID_BINDING');
  }
  async function request(path, options = {}) {
    if (!root.UmSpecGoogle?.googleFetch) throw failure('Google Calendar connection unavailable', 'CALENDAR_UNAVAILABLE');
    const response = await root.UmSpecGoogle.googleFetch(path, options, 'calendar');
    if (!response.ok) {
      const reason = await googleReason(response);
      throw Object.assign(failure('Google Calendar request failed (' + [response.status, reason].filter(Boolean).join(' ') + ')', 'CALENDAR_HTTP', response.status), { reason });
    }
    return response.status === 204 ? null : response.json();
  }
  // Google's reason token (for example insufficientPermissions) separates causes that share a status.
  async function googleReason(response) {
    try {
      const reason = (await response.json())?.error?.errors?.[0]?.reason;
      return typeof reason === 'string' && /^\w{1,64}$/.test(reason) ? reason : null;
    } catch { return null; }
  }
  const jsonOptions = (method, payload, headers = {}) => ({ method, headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(payload) });
  const calendarPath = id => BASE + '/calendars/' + encodeURIComponent(id);
  const marker = binding => 'umspec:v1:' + binding.hash;
  async function adopt(binding, calendar) {
    if (!calendar?.id || calendar.description !== marker(binding)) throw failure('Calendar ownership marker does not match', 'CALENDAR_OWNERSHIP');
    binding.calendarId = calendar.id;
    delete binding.calendarCreateIntent;
    await showCalendar(binding, calendar.id);
    return { id: calendar.id, etag: calendar.etag };
  }
  // Showing the calendar is a convenience the user can also do in Google Calendar, so a refusal must not stop dates
  // from syncing. Account and token failures still stop the job, because every later request would fail the same way.
  const ACCOUNT_FAILURES = new Set(['ACCOUNT_CHANGED', 'RECONNECT_REQUIRED', 'SCOPE_REQUIRED', 'CONFIG_REQUIRED', 'CALENDAR_UNAVAILABLE']);
  // UM Spec may only read the student's calendar list (calendarlist.readonly); Google refuses a change to it with 401.
  // So it checks whether its calendar is shown and, if not, says where to turn it on. Once shown it is never checked
  // again, so a student who later hides it keeps that choice.
  async function showCalendar(binding, id) {
    // syncEvent adopts once per event, so a recorded issue waits for the next sync job instead of repeating per event.
    if (binding.calendarVisibilityId === id || binding.calendarVisibilityIssue?.calendarId === id) return;
    try {
      const entry = await request(BASE + '/users/me/calendarList/' + encodeURIComponent(id));
      if (entry?.selected === true && entry.hidden !== true) {
        binding.calendarVisibilityId = id;
        delete binding.calendarVisibilityIssue;
        return;
      }
      binding.calendarVisibilityIssue = { calendarId: id, status: null, reason: 'hidden',
        message: 'Your dates are saved, but the UM Spec calendar is turned off in Google Calendar. Tick UM Spec under My calendars to see them.' };
    } catch (error) {
      if (ACCOUNT_FAILURES.has(error.code) || error.status === 401) throw error;
      const detail = error.status ? 'HTTP ' + [error.status, error.reason].filter(Boolean).join(' ') : 'no response from Google';
      binding.calendarVisibilityIssue = { calendarId: id, status: error.status ?? null, reason: error.reason ?? null,
        message: 'UM Spec could not check whether its calendar is shown (' + detail + '). If you cannot see your dates, turn on UM Spec under My calendars in Google Calendar.' };
    }
  }
  async function ensureCalendar(binding, interactive = false, persistBinding = async () => {}) {
    checkBinding(binding);
    if (binding.calendarId) {
      try { return adopt(binding, await request(calendarPath(binding.calendarId), { interactive })); }
      catch (error) {
        if (error.status === 404 || error.status === 410) throw failure('Managed calendar was deleted; choose a replacement explicitly', 'CALENDAR_DELETED', error.status);
        throw error;
      }
    }
    const matches = [], tokens = new Set();
    let pageToken;
    do {
      const page = await request(BASE + '/users/me/calendarList?maxResults=250&showHidden=true' + (pageToken ? '&pageToken=' + encodeURIComponent(pageToken) : ''), { interactive });
      if (!Array.isArray(page.items)) throw failure('Calendar listing is incomplete', 'CALENDAR_INCOMPLETE');
      for (const item of page.items) if (item.description === marker(binding) && !item.deleted) matches.push(item);
      pageToken = page.nextPageToken;
      if (pageToken && tokens.has(pageToken)) throw failure('Calendar pagination repeated', 'CALENDAR_INCOMPLETE');
      if (pageToken) tokens.add(pageToken);
    } while (pageToken);
    if (matches.length > 1) throw failure('Multiple managed calendars match; explicit selection is required', 'CALENDAR_AMBIGUOUS');
    if (matches.length) return adopt(binding, matches[0]);
    if (!binding.calendarCreateIntent) {
      // The worker persists this binding before calling again, so a restart can reconcile creation.
      binding.calendarCreateIntent = { state: 'prepared' };
      return { id: null, pending: true };
    }
    if (binding.calendarCreateIntent.state !== 'prepared') throw failure('Calendar creation is uncertain; no matching calendar was found yet', 'CALENDAR_CREATE_UNCERTAIN');
    binding.calendarCreateIntent.state = 'uncertain';
    await persistBinding();
    const options = jsonOptions('POST', { summary: 'UM Spec', description: marker(binding), timeZone: 'Asia/Kuala_Lumpur' });
    options.interactive = interactive;
    options.retry = false;
    return adopt(binding, await request(BASE + '/calendars', options));
  }
  async function readEvent(path) {
    try { return await request(path); }
    catch (error) {
      if (error.status === 404) return null;
      if (error.status === 410) return { status: 'cancelled' };
      throw error;
    }
  }
  async function syncEvent(binding, record, persistBinding) {
    checkBinding(binding);
    const calendar = core(), validation = calendar.validateEvent(record);
    if (!validation.valid) throw failure('Invalid calendar event: ' + validation.reasons.join('; '), 'INVALID_EVENT');
    const eventId = await calendar.stableEventId(binding.hash, record.sourceKey);
    const result = (action, reason) => ({ action, eventId, ...(reason ? { reason } : {}) });
    if (record.status !== 'confirmed') return result('review', record.status === 'cancelled' ? 'Source cancellation requires review' : 'Confirm the source date first');
    const managed = await ensureCalendar(binding, false, persistBinding);
    if (!managed.id) return result('pending', 'Persist calendar creation intent and retry');
    const payload = calendar.buildGoogleEvent({ ...record, reminderMinutes: binding.settings?.reminderMinutes ?? record.reminderMinutes }, eventId);
    const payloadHash = await calendar.eventPayloadHash(payload);
    const path = calendarPath(managed.id) + '/events/' + encodeURIComponent(eventId);
    const checkpoints = binding.calendarEvents || (binding.calendarEvents = {});
    const save = () => { checkpoints[eventId] = { sourceKey: record.sourceKey, sourceRevision: record.sourceRevision, appliedHash: payloadHash }; };
    const properties = { umspecBinding: binding.hash, umspecSource: record.sourceKey, umspecRevision: record.sourceRevision, umspecAppliedHash: payloadHash };
    let remote = await readEvent(path);
    function ownershipMatches(value) { return value?.extendedProperties?.private?.umspecBinding === binding.hash && value.extendedProperties.private.umspecSource === record.sourceKey; }
    async function actionFor(value) {
      if (value?.status === 'cancelled') return 'restore';
      if (!value) return checkpoints[eventId] ? 'restore' : 'create';
      if (!ownershipMatches(value)) return 'review';
      return calendar.decideEventAction({ ...record, payloadHash }, value, await calendar.eventPayloadHash(value));
    }
    let action = await actionFor(remote);
    if (action === 'create') {
      payload.extendedProperties = { private: properties };
      try {
        await request(calendarPath(managed.id) + '/events?sendUpdates=none', { ...jsonOptions('POST', payload), idempotent: true });
        save();
        return result('create');
      } catch (error) {
        // Deterministic IDs let a lost response or 409 reconcile without a second insert.
        const recovered = await readEvent(path);
        if (!recovered) throw error;
        remote = recovered;
        action = await actionFor(remote);
        if (action === 'skip') { save(); return result('create'); }
      }
    }
    if (action === 'skip') { save(); return result('skip'); }
    if (action !== 'update') return result(action, action === 'restore' ? 'Google event was deleted; restore requires review' : 'Calendar event changed or ownership could not be verified');
    if (!remote.etag) return result('review', 'Missing event version; update requires review');
    delete payload.id;
    payload.extendedProperties = { private: { ...remote.extendedProperties.private, ...properties } };
    try {
      await request(path + '?sendUpdates=none', jsonOptions('PATCH', payload, { 'If-Match': remote.etag }));
      save();
      return result('update');
    } catch (error) {
      if (error.status !== 412) throw error;
      await readEvent(path);
      return result('review', 'Calendar event changed during update');
    }
  }
  const api = { ensureCalendar, syncEvent };
  root.UmSpecCalendar = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(globalThis);
